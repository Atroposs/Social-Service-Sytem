﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClassLogic;
using ClasesDAO;
using System.Data.SqlClient;

namespace Pruebas
{
    [TestClass]
    public class SSLogicTest
    {
        [TestMethod]
        public void OpenConexionTest()
        {
            Conexion conexion = new Conexion();
            bool estadoDeConexion = conexion.Abrir();
            Assert.AreEqual(true, estadoDeConexion);
            
        }

        [TestMethod]
        [ExpectedException(typeof(SqlException))]
        public void ExeptionInOpenConexionTest()
        {
            Conexion conexion = new Conexion();
            conexion.Abrir();
           
        }

        [TestMethod]
        public void CloseConexcionTest()
        {
            Conexion conexion = new Conexion();
            bool estadoDeConexion = conexion.Cerrar();
            Assert.AreEqual(true, estadoDeConexion);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void ExeptioninCloseConexcionTest()
        {
            Conexion conexion = new Conexion();
            conexion.Cerrar();
           
        }

        [TestMethod]
        public void AgregarProyectoTest()
        {
            ProyectoDAO proyecto = new ProyectoDAO();
            bool query = proyecto.AgregarProyecto("ir al parque","2019-05-12","2019-05-13","ir al parque oll dai",3);
            Assert.AreEqual(true, query);
        }



    }
}
