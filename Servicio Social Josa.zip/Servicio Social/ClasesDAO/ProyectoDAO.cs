﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ClasesDAO
{
    public class ProyectoDAO : Conexion
    {

    public struct DatosProyecto
        {
            public int Identificador;
            public string Nombre;
            public string FechaDeInicio;
            public string FechaDeTerminacion;
            public string Descripcion;
            public int NumeroMaximoDeAlumnos;
        }
        public bool AgregarProyecto(string nombre, string fechainicio, string fechaterminacion, string descripcion, int nummaxalumnos)
        {
            bool proyectoAgregado = false;
            Abrir();

            string inserTo = $"INSERT INTO Proyectos (NombreProyecto,FechaInicio,FechaTerminacion,DescripcionProyecto,NumMaxAlumnosProyecto) " +
                             $"VALUES (@NombreProyecto,@FechaInicioProyecto,@FechaTerminacionProyecto,@DescripcionProyecto,@NumMaxAlumnosProyecto)";
            SqlCommand InsertarProyecto = new SqlCommand(inserTo, conectBD);
            SqlDataAdapter adapter = new SqlDataAdapter();

            try
            {

                InsertarProyecto.Parameters.AddWithValue("@NombreProyecto", nombre);
                InsertarProyecto.Parameters.AddWithValue("@FechaInicioProyecto", fechainicio);
                InsertarProyecto.Parameters.AddWithValue("@FechaTerminacionProyecto", fechaterminacion);
                InsertarProyecto.Parameters.AddWithValue("@DescripcionProyecto", descripcion);
                InsertarProyecto.Parameters.AddWithValue("@NumMaxAlumnosProyecto", nummaxalumnos);

                adapter.InsertCommand = InsertarProyecto;
                adapter.InsertCommand.ExecuteNonQuery();
            }
            catch (SqlException e)
            {
                Console.WriteLine("Error al agregar los parametros de proyecto");
                Console.WriteLine(e.Message);
            }
            finally
            {
                Cerrar();
            }

            proyectoAgregado = true;
            return proyectoAgregado;

        }

        public void ValidarProyecto(int idproyecto, string matricula)
        {
            Abrir();

            string inserTo = $"INSERT INTO Proyectos_Alumnos (IdProyecto,Matricula)" + $"VALUES (@IdProyecto,@Matricula)";
            SqlCommand InsertarAsignacionProyecto = new SqlCommand(inserTo, conectBD);
            SqlDataAdapter adapter = new SqlDataAdapter();

            try
            {
               InsertarAsignacionProyecto.Parameters.AddWithValue("@IdProyecto", idproyecto);
               InsertarAsignacionProyecto.Parameters.AddWithValue("@Matricula", matricula);

               adapter.InsertCommand = InsertarAsignacionProyecto;
               adapter.InsertCommand.ExecuteNonQuery();
            }
            catch(SqlException e)
            {
                Console.WriteLine("Error al agregar los parametros de asignacion de proyecto-alumno");
                Console.WriteLine(e.Message);
            }

            Cerrar();
        }


        public List<DatosProyecto> ObtenerProyectosExistentes()
        {
            Abrir();

            string selecTo = "select * from Proyectos"; 
            SqlCommand selectProyectos = new SqlCommand(selecTo, conectBD);
            SqlDataReader reader = selectProyectos.ExecuteReader();
            List<DatosProyecto> proyectos = new List<DatosProyecto>();

            try
            {
 
                while (reader.Read())
                {
                    DatosProyecto proyecto = new DatosProyecto();
                    proyecto.Identificador = reader.GetInt32(0);
                    proyecto.Nombre = reader.GetString(1);
                    proyecto.FechaDeInicio = reader.GetString(2);
                    proyecto.FechaDeTerminacion = reader.GetString(3);
                    proyecto.Descripcion = reader.GetString(4);
                    proyecto.NumeroMaximoDeAlumnos = reader.GetInt32(5);
                    proyectos.Add(proyecto);
                };

            }

            catch (SqlException ex)
            {
                Console.WriteLine("Error en la lectura de la tabla de proyectos");
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Cerrar();
                
            }
            return proyectos;
        }
    }

}
