﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LogicaDeAlumno;
using ConeccionBaseDedatos;

namespace Proyecto_SISS
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
        
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Alumno alumno = new Alumno();
            alumno.ApellidoPaterno = textBoxApellidoPaterno.Text;
            alumno.ApellidoMaterno = textBoxApellidoMaterno.Text;
            alumno.Nombre = textBoxNambre.Text;
            alumno.Matricula = textBoxMatricula.Text;
            alumno.Semestre = textBoxSemestre.Text;
            alumno.Carrera = textBoxCarrera.Text;
            alumno.Telefono = textBoxTelefono.Text;
            alumno.CorreroElectronico = textBoxCorreoElectronico.Text;

            Conexion conexion1 = new Conexion(); // instansiamos para poder usar el metodo crear contacto de la capa coexion

            bool creado = conexion1.RegistrarAlumno(alumno); //mandamos a llamar el metodo crear contacto y le mandamos el objeto contacto

        }
        }
    }

