﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;


namespace ConeccionBaseDedatos
{
    public class Conexion
    {
        string server = "Server=localhost; Database=principal; User Id=proyecto; Password=12345";

        public SqlConnection conectBD = new SqlConnection();

        public Conexion()  // Autenticacion de usuario con el servidos SQL
        {
            conectBD.ConnectionString = server;
        }

        public void Abrir()
        {

            try
            {
                conectBD.Open();
                Console.WriteLine("Conexion abierta");

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al abrir la Base de Datos" + ex.Message);
            }

        }

        public bool RegistrarAlumno(Alumno AlumnoDB)
        {
            try
            {
                Abrir();
                string inserTo = "INSERT INTO alumno (apellidopaterno,apellidomaterno,nombre,matricula,semestre,carrera,correroelectronico,telefono) VALUES (@apellidopaterno,@apellidomaterno,@nombre,@matricula,@semestre,@carrera,@correroelectronico,@telefono)";
                SqlCommand alumno = new SqlCommand(inserTo, conectBD);
                alumno.Parameters.AddWithValue("@apellidopaterno", AlumnoDB.ApellidoPaterno);
                alumno.Parameters.AddWithValue("@apellidomaterno", AlumnoDB.ApellidoMaterno);
                alumno.Parameters.AddWithValue("@nombre", AlumnoDB.Nombre);
                alumno.Parameters.AddWithValue("@matricula", AlumnoDB.Matricula);
                alumno.Parameters.AddWithValue("@semestre", AlumnoDB.Semestre);
                alumno.Parameters.AddWithValue("@carrera", AlumnoDB.Carrera);
                alumno.Parameters.AddWithValue("@correoelectronico", AlumnoDB.CorreroElectronico);
                alumno.Parameters.AddWithValue("@telefono", AlumnoDB.Telefono);
                int result = alumno.ExecuteNonQuery();
                return result > 0;


            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
            finally
            {
                Cerrar();
            }


        }



        public bool RegitrarDependencia(Dependencia DependenciaDB)

        {
            try
            {
                Abrir();
                try
                {
                    string inserTo = "INSERT INTO dependencia (nombre,direccion,encargado,telefono,giro,descripcion) VALUES (@nombre,@direccion,@encargado,@telefono,@giro,@descripcion)";
                    SqlCommand dependencia = new SqlCommand(inserTo, conectBD);
                    dependencia.Parameters.AddWithValue("@nombre", DependenciaDB.Nombre);
                    dependencia.Parameters.AddWithValue("@direccion", DependenciaDB.Direccion);
                    dependencia.Parameters.AddWithValue("@encargado", DependenciaDB.Encargado);
                    dependencia.Parameters.AddWithValue("@telefono", DependenciaDB.Telefono);
                    dependencia.Parameters.AddWithValue("@giro", DependenciaDB.Giro);
                    dependencia.Parameters.AddWithValue("@descripcion", DependenciaDB.Descripcion);
                    int result = dependencia.ExecuteNonQuery();
                    return result > 0;
                    //Console.WriteLine(result);
                }
                catch (SqlException ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
                finally
                {
                    Cerrar();
                }

            }
            catch (SqlException ex)
            {
                return false;
                // Console.WriteLine(ex.Message);
            }

        }


        public void Cerrar()
        {
            try
            {
                conectBD.Close();
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        public List<Alumno> VerAlumnno()
        {
            try
            {
                Abrir();

                string selecTo = "select * from alumno"; //query
                SqlCommand select = new SqlCommand(selecTo, conectBD);
                SqlDataReader reader = select.ExecuteReader();
                List<Alumno> alumnos = new List<Alumno>();

                while (reader.Read())
                {
                    Alumno alumno = new Alumno();
                    alumno.ApellidoPaterno = reader[0].ToString();
                    alumno.ApellidoMaterno = reader[1].ToString();
                    alumno.Nombre = reader[2].ToString();
                    alumno.Matricula = reader[3].ToString();
                    alumno.Semestre = reader[4].ToString();
                    alumno.Carrera = reader[5].ToString();
                    alumno.CorreroElectronico = reader[6].ToString();
                    alumno.Telefono = reader[7].ToString();
                    alumnos.Add(alumno);
                };

                return alumnos;
            }

            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Cerrar();
            }
            return null;
        }


    }

}
