﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;


namespace ClasesDAO
{
    public class Conexion
    {
        string ServerData = "Server = JOSAFAT; Database = ServicioSocial; User Id = Admin; Password = 123; ";

        public SqlConnection conectBD = new SqlConnection();
        public Conexion()
        {
            conectBD.ConnectionString = ServerData;
        }

        public bool Abrir()
        {
            bool ConexionAbierta = false;

            try
            {
                conectBD.Open();
                Console.WriteLine("Conexion abierta");

            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine("Error al abrir la Base de Datos" + ex.Message);
            }

            if (conectBD.State == System.Data.ConnectionState.Open)
            {
                ConexionAbierta = true;
            }

            return ConexionAbierta;


        }

        public bool Cerrar()//hacer un throw exception here
        {
            bool ConexionCerrada = false;

            try
            {
                conectBD.Close();
                Console.WriteLine("Conexion Cerrada");
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Error al cerrar la Base de Datos" + ex.Message);

            }

            if (conectBD.State == System.Data.ConnectionState.Closed)
            {
                ConexionCerrada = true;
            }

            return ConexionCerrada;

        }
    }
}
}
