﻿using System;
using System.Data.SqlClient;
using ClasesDAO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ServicioSocialTest
{
    [TestClass]
    public class SSISTest
    {
        [TestMethod]
        public void OpenConexionTest()
        {
            Conexion conexion = new Conexion();
            bool estadoDeConexion = conexion.Abrir();
            Assert.AreEqual(true, estadoDeConexion);

        }

        [TestMethod]
        [ExpectedException(typeof(SqlException))]
        public void ExeptionInOpenConexionTest()
        {
            Conexion conexion = new Conexion();
            conexion.Abrir();

        }

        [TestMethod]
        public void CloseConexcionTest()
        {
            Conexion conexion = new Conexion();
            bool estadoDeConexion = conexion.Cerrar();
            Assert.AreEqual(true, estadoDeConexion);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void ExeptioninCloseConexcionTest()
        {
            Conexion conexion = new Conexion();
            conexion.Cerrar();

        }

        [TestMethod]
        public void AgregarProyectoTest()
        {
            ProyectoDAO proyecto = new ProyectoDAO();
            bool query = proyecto.AgregarProyecto("ir al parque", "2019-05-12", "2019-05-13", "ir al parque oll dai", 3);
            Assert.AreEqual(true, query);
        }
    }
}
