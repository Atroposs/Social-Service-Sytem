﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ServicioSocialLogic
{
    public class Alumno
    {
        public string ApellidoPaterno { get; set; }
        public string ApellidoMaterno { get; set; }
        public string Nombre { get; set; }
        public string Matricula { get; set; }
        public string Semestre { get; set; }
        public string Carrera { get; set; }
        public string CorreroElectronico { get; set; }
        public string Telefono { get; set; }

    }
}
