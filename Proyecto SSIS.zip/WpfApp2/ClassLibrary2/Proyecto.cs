﻿using ClasesDAO;
using System;

namespace ServicioSocialLogic
{
    public class Proyecto
    {
        ProyectoDAO proyectoDAO = new ProyectoDAO();
        public struct datosProyecto
        {
            public int Identificador;
            public string Nombre;
            public string FechaDeInicio;
            public string FechaDeTerminacion;
            public string Descripcion;
            public int NumeroMaximoDeAlumnos;
        }

        private int idProyecto;
        public int IdProyecto
        {
            get
            {
                return idProyecto;
            }
            set
            {
                idProyecto = value;
            }
        }

        private string nombreProyecto;
        public string NombreProyecto
        {
            get
            {
                return nombreProyecto;
            }
            set
            {
                nombreProyecto = value;
            }
        }

        private string fechaInicioProyecto;
        public string FechaInicioProyecto
        {
            get
            {
                return fechaInicioProyecto;
            }
            set
            {
                fechaInicioProyecto = value;
            }
        }

        private string fechaTerminacionProyecto;
        public string FechaTerminacionProyecto
        {
            get
            {
                return fechaTerminacionProyecto;
            }
            set
            {
                fechaTerminacionProyecto = value;
            }
        }

        private string descripcionProyecto;
        public string DescripcionProyecto
        {
            get
            {
                return descripcionProyecto;
            }
            set
            {
                descripcionProyecto = value;
            }
        }


        private int numMaxAlumnosProyecto;
        public int NumMaxAlumnosProyecto
        {
            get
            {
                return numMaxAlumnosProyecto;
            }
            set
            {
                numMaxAlumnosProyecto = value;
            }
        }

        public Proyecto(string nombre, string fechainicio, string fechaterminacion, string descripcion, int nummaxalumnos)
        {
            nombreProyecto = nombre;
            fechaInicioProyecto = fechainicio;
            fechaTerminacionProyecto = fechaterminacion;
            descripcionProyecto = descripcion;
            numMaxAlumnosProyecto = nummaxalumnos;
        }
        public void SubirProyecto()
        {
            proyectoDAO.AgregarProyecto(nombreProyecto, fechaInicioProyecto, fechaTerminacionProyecto, descripcionProyecto, numMaxAlumnosProyecto);
        }


        public void ValidarProyecto(string matricula)
        {
            proyectoDAO.ValidarProyecto(idProyecto, matricula);
        }

    }
}
