﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ServicioSocialLogic
{
    public class Dependencia
    {
        public string IdDependencia { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Encargado { get; set; }
        public string Telefono { get; set; }
        public string Giro { get; set; }
        public string Descripcion { get; set; }
    }
}
